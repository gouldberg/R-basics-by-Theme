library(nycflights13)
library(tidyverse)
library(dplyr)



# ---------------------------------------------------------------------------
# cumulative and roolign aggregates
# ---------------------------------------------------------------------------
( x <- 1:10 )


cumsum(x)


cummean(x)


cummin(x)


cummax(x)


cumall(x)


cumany(x)